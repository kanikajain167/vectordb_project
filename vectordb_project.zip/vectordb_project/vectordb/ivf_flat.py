"""
IVF-Flat: the approximate index.

The idea: instead of comparing a query against every single vector (what
BruteForceIndex does), first group all vectors into `nlist` clusters
using k-means (see kmeans.py). To answer a query, find the `nprobe`
clusters whose centroid is closest to the query, and only brute-force
search inside those clusters. Because nprobe is much smaller than nlist,
this looks at only a fraction of the data set, which is why it is fast --
and it is "approximate" because the true nearest neighbour could in theory
sit in a cluster we never probed.

nlist  - how many clusters to split the data into (more clusters = smaller,
         faster-to-scan clusters, but a higher chance of missing the right
         one).
nprobe - how many of those clusters to actually search per query (higher
         nprobe = closer to exact brute force, but slower).

On deletion: each cluster is stored as a plain Python dict {id: vector}
rather than a single packed numpy matrix. A dict lets us delete a vector
in O(1) by just popping the key. If we had instead kept each cluster as a
flat numpy array (which is a little faster to search), deleting one
vector would mean rebuilding that whole cluster's array, i.e. O(cluster
size) every time something is deleted. We picked the dict representation
on purpose so delete stays cheap, and only pay the cost of stacking the
dict's values into a matrix at search time.
"""

import numpy as np

from .kmeans import kmeans


def _normalise_1d(vector):
    vector = np.asarray(vector, dtype=np.float32)
    norm = np.linalg.norm(vector)
    return vector / norm if norm > 0 else vector


def _normalise_2d(vectors):
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return vectors / norms


class IVFFlatIndex:
    def __init__(self, dim, nlist=256, nprobe=8, seed=42):
        self.dim = dim
        self.nlist = nlist
        self.nprobe = nprobe
        self.seed = seed

        self.centroids = None            # (nlist, dim) once trained
        self.clusters = {}               # cluster_id -> {id: vector}
        self.id_to_cluster = {}          # id -> cluster_id
        self._next_id = 0
        self._trained = False

    def __len__(self):
        return len(self.id_to_cluster)

    # ------------------------------------------------------------------
    # training (this is the "build the clusters" step, must run once
    # before any insert/search)
    # ------------------------------------------------------------------
    def train(self, vectors, n_iter=20, verbose=False):
        vectors = np.asarray(vectors, dtype=np.float32)
        vectors = _normalise_2d(vectors)
        centroids, assignments = kmeans(
            vectors, self.nlist, n_iter=n_iter, seed=self.seed, verbose=verbose
        )
        self.centroids = centroids
        self.clusters = {c: {} for c in range(self.nlist)}
        self._trained = True
        return assignments

    def _nearest_cluster(self, vector):
        sims = self.centroids @ vector
        return int(np.argmax(sims))

    def _require_trained(self):
        if not self._trained:
            raise RuntimeError(
                "IVFFlatIndex has not been trained yet. Call .train(vectors) "
                "once on a representative sample before insert/search."
            )

    # ------------------------------------------------------------------
    # insert
    # ------------------------------------------------------------------
    def insert(self, vector, vec_id=None):
        self._require_trained()
        vector = _normalise_1d(vector)

        if vec_id is None:
            vec_id = self._next_id
        self._next_id = max(self._next_id, vec_id + 1)

        c = self._nearest_cluster(vector)
        self.clusters[c][vec_id] = vector
        self.id_to_cluster[vec_id] = c
        return vec_id

    def insert_batch(self, vectors, ids=None, assignments=None):
        """Bulk insert. If `assignments` is already known (e.g. straight
        after train(), which computes them anyway) pass it in to avoid
        recomputing the nearest centroid for every vector."""
        self._require_trained()
        vectors = np.asarray(vectors, dtype=np.float32)
        vectors = _normalise_2d(vectors)
        n = vectors.shape[0]

        if ids is None:
            ids = list(range(self._next_id, self._next_id + n))
        if n:
            self._next_id = max(self._next_id, int(max(ids)) + 1)

        if assignments is None:
            sims = vectors @ self.centroids.T
            assignments = np.argmax(sims, axis=1)

        for vid, vec, c in zip(ids, vectors, assignments):
            c = int(c)
            self.clusters[c][int(vid)] = vec
            self.id_to_cluster[int(vid)] = c
        return list(ids)

    # ------------------------------------------------------------------
    # delete
    # ------------------------------------------------------------------
    def delete(self, vec_id):
        self._require_trained()
        if vec_id not in self.id_to_cluster:
            raise KeyError(f"id {vec_id} not found in IVFFlatIndex")
        c = self.id_to_cluster[vec_id]
        del self.clusters[c][vec_id]
        del self.id_to_cluster[vec_id]

    # ------------------------------------------------------------------
    # search
    # ------------------------------------------------------------------
    def search(self, query, k=10):
        self._require_trained()
        q = _normalise_1d(query)

        centroid_sims = self.centroids @ q
        nprobe = min(self.nprobe, self.nlist)
        probe_clusters = np.argpartition(-centroid_sims, nprobe - 1)[:nprobe]

        candidate_ids = []
        candidate_vecs = []
        for c in probe_clusters:
            cluster = self.clusters[int(c)]
            if not cluster:
                continue
            candidate_ids.extend(cluster.keys())
            candidate_vecs.append(np.array(list(cluster.values()), dtype=np.float32))

        if not candidate_ids:
            return []

        candidate_vecs = np.vstack(candidate_vecs)
        sims = candidate_vecs @ q
        k = min(k, len(candidate_ids))
        top_idx = np.argpartition(-sims, k - 1)[:k]
        top_idx = top_idx[np.argsort(-sims[top_idx])]
        return [(int(candidate_ids[i]), float(sims[i])) for i in top_idx]
