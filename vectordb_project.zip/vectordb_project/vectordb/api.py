"""
VectorDB: the one class most code should actually talk to.

It wraps BruteForceIndex (exact) and IVFFlatIndex (approximate) behind one
small, simple API: insert, search, delete. Every insert/delete is applied
to both indexes together so they never fall out of sync, which makes it
easy to compare the two side by side (the benchmark script does exactly
that).
"""

from .brute_force import BruteForceIndex
from .ivf_flat import IVFFlatIndex


class VectorDB:
    def __init__(self, dim, nlist=256, nprobe=8, seed=42):
        self.dim = dim
        self.exact = BruteForceIndex(dim)
        self.approx = IVFFlatIndex(dim, nlist=nlist, nprobe=nprobe, seed=seed)

    def __len__(self):
        return len(self.exact)

    def train_approx(self, vectors, n_iter=20, verbose=False):
        """Must be called once, on a representative sample of vectors,
        before the approximate index can be used. This builds the
        clusters that IVF-Flat searches over."""
        return self.approx.train(vectors, n_iter=n_iter, verbose=verbose)

    def bulk_load(self, vectors, ids=None, assignments=None):
        """Load many vectors at once into both indexes. Call
        train_approx() first."""
        ids = self.exact.insert_batch(vectors, ids=ids)
        self.approx.insert_batch(vectors, ids=ids, assignments=assignments)
        return ids

    def insert(self, vector, vec_id=None):
        vec_id = self.exact.insert(vector, vec_id=vec_id)
        self.approx.insert(vector, vec_id=vec_id)
        return vec_id

    def delete(self, vec_id):
        self.exact.delete(vec_id)
        self.approx.delete(vec_id)

    def search(self, query, k=10, backend="both"):
        """backend: 'exact', 'approx', or 'both' (default)."""
        if backend == "exact":
            return {"exact": self.exact.search(query, k)}
        if backend == "approx":
            return {"approx": self.approx.search(query, k)}
        return {
            "exact": self.exact.search(query, k),
            "approx": self.approx.search(query, k),
        }
