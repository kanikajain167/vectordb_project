"""
Exact brute-force nearest neighbour index.

This is the "ground truth" index. It does not do anything clever, it just
keeps every vector in one big numpy matrix and, for a query, multiplies the
query against the whole matrix to get cosine similarity to every single
stored vector, then picks the top-k. That is O(N) per query, which is
exactly why an approximate index (see ivf_flat.py) is needed once N gets
large. This index exists so we have something to compare the approximate
index against.

All vectors are L2-normalised on the way in, so cosine similarity between
two normalised vectors is just their dot product. That lets us replace a
slow cosine-similarity formula with a single fast matrix multiplication.
"""

import numpy as np


def _normalise(vectors):
    """L2-normalise rows of a 2D array. Rows that are all zero are left as
    zero (there is nothing sensible to divide by)."""
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return vectors / norms


class BruteForceIndex:
    """Exact cosine-similarity index using plain numpy, nothing else."""

    def __init__(self, dim):
        self.dim = dim
        self._vectors = np.zeros((0, dim), dtype=np.float32)
        self._ids = np.zeros((0,), dtype=np.int64)
        # maps an external id -> row number inside self._vectors
        self._id_to_row = {}
        self._next_id = 0

    def __len__(self):
        return len(self._ids)

    # ------------------------------------------------------------------
    # insert
    # ------------------------------------------------------------------
    def insert(self, vector, vec_id=None):
        """Insert a single vector. Returns the id it was stored under."""
        vector = np.asarray(vector, dtype=np.float32).reshape(1, -1)
        vector = _normalise(vector)

        if vec_id is None:
            vec_id = self._next_id
        self._next_id = max(self._next_id, vec_id + 1)

        self._vectors = np.vstack([self._vectors, vector])
        self._ids = np.append(self._ids, np.int64(vec_id))
        self._id_to_row[vec_id] = len(self._ids) - 1
        return vec_id

    def insert_batch(self, vectors, ids=None):
        """Insert many vectors at once. Much faster than calling insert()
        in a loop because it avoids growing the numpy array one row at a
        time. Use this for the initial bulk load."""
        vectors = np.asarray(vectors, dtype=np.float32)
        if vectors.ndim == 1:
            vectors = vectors.reshape(1, -1)
        n = vectors.shape[0]
        vectors = _normalise(vectors)

        if ids is None:
            ids = list(range(self._next_id, self._next_id + n))
        ids = np.asarray(ids, dtype=np.int64)
        if n:
            self._next_id = max(self._next_id, int(ids.max()) + 1)

        start_row = len(self._ids)
        if len(self._ids) == 0:
            self._vectors = vectors
        else:
            self._vectors = np.vstack([self._vectors, vectors])
        self._ids = np.concatenate([self._ids, ids])

        for i, vid in enumerate(ids):
            self._id_to_row[int(vid)] = start_row + i
        return ids.tolist()

    # ------------------------------------------------------------------
    # delete
    # ------------------------------------------------------------------
    def delete(self, vec_id):
        """Remove a vector by id. Raises KeyError if it does not exist."""
        if vec_id not in self._id_to_row:
            raise KeyError(f"id {vec_id} not found in BruteForceIndex")
        row = self._id_to_row[vec_id]
        self._vectors = np.delete(self._vectors, row, axis=0)
        self._ids = np.delete(self._ids, row, axis=0)
        del self._id_to_row[vec_id]
        # every row after the deleted one just shifted up by one place,
        # so the row bookkeeping has to be fixed to match
        for k, v in self._id_to_row.items():
            if v > row:
                self._id_to_row[k] = v - 1

    # ------------------------------------------------------------------
    # search
    # ------------------------------------------------------------------
    def search(self, query, k=10):
        """Return the top-k (id, score) pairs by cosine similarity,
        sorted best first. This scans every stored vector, so it is exact."""
        if len(self._ids) == 0:
            return []
        q = np.asarray(query, dtype=np.float32).reshape(1, -1)
        q = _normalise(q)

        scores = (self._vectors @ q.T).ravel()
        k = min(k, len(scores))
        # argpartition first (O(N)) then sort only the top-k (O(k log k)),
        # cheaper than sorting all N scores when N is large
        top_idx = np.argpartition(-scores, k - 1)[:k]
        top_idx = top_idx[np.argsort(-scores[top_idx])]
        return [(int(self._ids[i]), float(scores[i])) for i in top_idx]
