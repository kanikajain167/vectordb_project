"""
A small k-means implementation written from scratch with numpy, used to
build the clusters ("cells") for the IVF-Flat index.

Because every vector fed into this project is L2-normalised, we use cosine
similarity (dot product) instead of Euclidean distance everywhere,
including here. That makes this "spherical k-means": the assignment step
picks the centroid with the highest dot product, and the update step
re-normalises each new centroid back onto the unit sphere. This keeps the
clustering consistent with the similarity metric the rest of the project
uses (see brute_force.py).
"""

import numpy as np


def _kmeans_plus_plus_init(X, k, rng):
    """Pick k initial centroids using the k-means++ rule: start with one
    random point, then repeatedly pick the next centroid with probability
    proportional to its squared distance from the closest centroid picked
    so far. This gives much better starting points than picking k random
    rows, and avoids most of the "bad seed -> useless clusters" problems."""
    n = X.shape[0]
    centroids = np.zeros((k, X.shape[1]), dtype=X.dtype)
    first = rng.integers(n)
    centroids[0] = X[first]

    closest_dist_sq = np.sum((X - centroids[0]) ** 2, axis=1)
    for i in range(1, k):
        total = closest_dist_sq.sum()
        if total <= 0:
            # all remaining points are identical to a chosen centroid,
            # just pick any point to move on
            next_idx = rng.integers(n)
        else:
            probs = closest_dist_sq / total
            next_idx = rng.choice(n, p=probs)
        centroids[i] = X[next_idx]
        dist_sq = np.sum((X - centroids[i]) ** 2, axis=1)
        closest_dist_sq = np.minimum(closest_dist_sq, dist_sq)
    return centroids


def kmeans(X, k, n_iter=20, seed=42, verbose=False):
    """Cluster rows of X (assumed L2-normalised) into k clusters.

    Returns:
        centroids   - (k, dim) float32 array, each row L2-normalised
        assignments - (n,) int64 array, cluster id for every row of X
    """
    if k > X.shape[0]:
        raise ValueError(
            f"Cannot make {k} clusters out of only {X.shape[0]} points"
        )

    rng = np.random.default_rng(seed)
    X = np.asarray(X, dtype=np.float32)
    n = X.shape[0]

    centroids = _kmeans_plus_plus_init(X, k, rng)
    assignments = np.full(n, -1, dtype=np.int64)

    for it in range(n_iter):
        # assignment step: cosine similarity to every centroid, pick the
        # best one for every point in a single matrix multiply
        sims = X @ centroids.T                 # (n, k)
        new_assignments = np.argmax(sims, axis=1)

        if np.array_equal(new_assignments, assignments):
            if verbose:
                print(f"kmeans: converged after {it} iterations")
            break
        assignments = new_assignments

        # update step: move each centroid to the mean of its members,
        # then re-normalise so it stays on the unit sphere (spherical
        # k-means). Empty clusters are re-seeded with a random point so
        # we never end up with a "dead" cluster that nothing can match.
        for c in range(k):
            members = X[assignments == c]
            if len(members) == 0:
                centroids[c] = X[rng.integers(n)]
                continue
            mean_vec = members.mean(axis=0)
            norm = np.linalg.norm(mean_vec)
            centroids[c] = mean_vec / norm if norm > 0 else mean_vec

    if verbose:
        sizes = np.bincount(assignments, minlength=k)
        print(
            f"kmeans: cluster sizes -> min={sizes.min()}, "
            f"max={sizes.max()}, mean={sizes.mean():.1f}"
        )

    return centroids.astype(np.float32), assignments
