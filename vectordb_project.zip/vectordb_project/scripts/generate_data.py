"""
STEP 1 of the pipeline.

What this script does:
1. Builds a text corpus of at least 50,000 short sentences. The sentences
   are generated from topic-specific word banks and sentence templates
   (40 topics such as sports, cooking, space, finance, medicine, etc), not
   from random word soup. This gives the corpus real topical structure, so
   when it is embedded, the vectors naturally form clusters (one loose
   cluster per topic) instead of being spread out evenly like random
   vectors would be. That "lumpy" geometry is exactly what makes the
   approximate index (IVF-Flat) an interesting thing to test, because a
   real vector database also sees lumpy, clustered data in practice.
2. Turns every sentence into a vector using TF-IDF followed by Truncated
   SVD (this combination is often called "LSA"). This is a real,
   well-known text-embedding technique, it does not need to download any
   external model, and it runs fast even on 50k+ documents.
3. Sets aside 500 of the sentences as a held-out query set (they are
   removed from the main corpus first, so a query is never trivially
   equal to a stored vector).
4. Computes the exact top-10 nearest neighbours for every one of those 500
   queries using plain brute-force search. This becomes the "ground
   truth" the benchmark script (step 3) uses to score the approximate
   index's recall.

Run:
    python scripts/generate_data.py

Everything is written to ./data/:
    corpus.json           - {"id": ..., "text": ..., "topic": ...} for every
                             stored sentence
    embeddings.npy         - (N, DIM) float32, L2-normalised, row i belongs
                             to id i
    query_texts.json       - the 500 held-out query sentences
    query_embeddings.npy   - (500, DIM) float32, L2-normalised
    ground_truth.npy       - (500, 10) int64, exact top-10 ids per query
    embedder.pkl           - fitted TfidfVectorizer + TruncatedSVD, so a
                             brand-new sentence can be embedded the same way
                             later (used by scripts/demo_query.py)
"""

import json
import os
import pickle
import random
import sys

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from vectordb.brute_force import BruteForceIndex  # noqa: E402

SEED = 42
N_SENTENCES = 55000          # comfortably over the 50,000 minimum
N_QUERIES = 500
EMBED_DIM = 128
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

random.seed(SEED)
np.random.seed(SEED)

# ---------------------------------------------------------------------
# Topic word banks. Each topic has its own subjects, verbs, objects and
# adjectives, so sentences from the same topic reuse the same vocabulary
# and end up looking similar to a text embedder -- which is what creates
# the "lumpy", clustered geometry described above.
# ---------------------------------------------------------------------
TOPICS = {
    "sports": dict(
        subjects=["the striker", "the coach", "the referee", "the goalkeeper", "the champion", "the rookie"],
        verbs=["trained hard for", "won", "lost", "prepared carefully for", "celebrated after", "analysed"],
        objects=["the final match", "the championship", "the tournament", "the league title", "the penalty shootout", "the season opener"],
        adjectives=["exciting", "tense", "historic", "thrilling", "disappointing", "unexpected"],
    ),
    "cooking": dict(
        subjects=["the chef", "the home cook", "the baker", "the food critic", "the restaurant owner"],
        verbs=["seasoned", "grilled", "baked", "chopped", "simmered", "plated"],
        objects=["the fresh vegetables", "the roasted chicken", "the sourdough bread", "the pasta sauce", "the chocolate cake", "the vegetable soup"],
        adjectives=["delicious", "spicy", "savoury", "fresh", "rich", "aromatic"],
    ),
    "finance": dict(
        subjects=["the investor", "the analyst", "the bank", "the startup founder", "the trader"],
        verbs=["reviewed", "invested in", "forecasted", "reported on", "questioned"],
        objects=["the quarterly earnings", "the stock market", "the interest rates", "the company valuation", "the investment portfolio"],
        adjectives=["volatile", "steady", "risky", "profitable", "uncertain", "record-breaking"],
    ),
    "medicine": dict(
        subjects=["the doctor", "the surgeon", "the nurse", "the researcher", "the patient"],
        verbs=["examined", "treated", "diagnosed", "monitored", "prescribed medication for"],
        objects=["the new patient", "the surgical procedure", "the chronic condition", "the clinical trial", "the recovery process"],
        adjectives=["urgent", "routine", "complicated", "rare", "successful", "critical"],
    ),
    "space": dict(
        subjects=["the astronaut", "the engineer", "the space agency", "the telescope operator", "the mission control team"],
        verbs=["launched", "tracked", "photographed", "analysed data from", "prepared for a mission to"],
        objects=["the orbiting satellite", "the distant galaxy", "the lunar surface", "the space station", "the newly discovered planet"],
        adjectives=["distant", "unexplored", "massive", "faint", "record-setting", "historic"],
    ),
    "gardening": dict(
        subjects=["the gardener", "the landscaper", "the botanist", "the homeowner"],
        verbs=["planted", "watered", "pruned", "fertilised", "harvested"],
        objects=["the rose bushes", "the vegetable patch", "the flower beds", "the fruit trees", "the herb garden"],
        adjectives=["blooming", "overgrown", "healthy", "colourful", "fragrant"],
    ),
    "music": dict(
        subjects=["the composer", "the guitarist", "the singer", "the orchestra", "the producer"],
        verbs=["rehearsed", "recorded", "performed", "composed", "remixed"],
        objects=["the new album", "the symphony", "the live concert", "the guitar solo", "the closing track"],
        adjectives=["melodic", "energetic", "haunting", "upbeat", "experimental"],
    ),
    "travel": dict(
        subjects=["the tourist", "the tour guide", "the backpacker", "the travel blogger", "the airline"],
        verbs=["explored", "booked", "recommended", "photographed", "described"],
        objects=["the mountain village", "the coastal town", "the ancient temple", "the crowded market", "the scenic hiking trail"],
        adjectives=["breathtaking", "remote", "crowded", "peaceful", "unforgettable"],
    ),
    "technology": dict(
        subjects=["the engineer", "the startup", "the developer", "the tech company", "the researcher"],
        verbs=["released", "tested", "optimised", "redesigned", "launched"],
        objects=["the new software update", "the mobile application", "the cloud platform", "the search algorithm", "the hardware prototype"],
        adjectives=["innovative", "buggy", "reliable", "fast", "cutting-edge"],
    ),
    "weather": dict(
        subjects=["the meteorologist", "the news anchor", "the farmer", "the residents"],
        verbs=["forecasted", "warned about", "monitored", "prepared for"],
        objects=["the heavy rainfall", "the approaching storm", "the heatwave", "the sudden snowfall", "the strong winds"],
        adjectives=["severe", "unusual", "sudden", "prolonged", "mild"],
    ),
    "politics": dict(
        subjects=["the senator", "the mayor", "the committee", "the minister", "the political party"],
        verbs=["debated", "proposed", "opposed", "voted on", "announced"],
        objects=["the new policy", "the budget proposal", "the trade agreement", "the election results", "the reform bill"],
        adjectives=["controversial", "long-awaited", "divisive", "historic", "unpopular"],
    ),
    "education": dict(
        subjects=["the teacher", "the professor", "the student", "the school board", "the tutor"],
        verbs=["explained", "graded", "designed", "reviewed", "discussed"],
        objects=["the final exam", "the research paper", "the new curriculum", "the classroom project", "the lecture notes"],
        adjectives=["challenging", "detailed", "outdated", "engaging", "thorough"],
    ),
    "wildlife": dict(
        subjects=["the zoologist", "the park ranger", "the photographer", "the conservationist"],
        verbs=["observed", "tracked", "photographed", "studied", "protected"],
        objects=["the migrating herd", "the endangered species", "the nesting birds", "the forest ecosystem", "the coral reef"],
        adjectives=["endangered", "rare", "majestic", "elusive", "thriving"],
    ),
    "movies": dict(
        subjects=["the director", "the actor", "the critic", "the film studio", "the audience"],
        verbs=["praised", "criticised", "filmed", "edited", "premiered"],
        objects=["the new blockbuster", "the independent film", "the closing scene", "the sequel", "the documentary"],
        adjectives=["gripping", "predictable", "visually stunning", "underwhelming", "award-winning"],
    ),
    "fashion": dict(
        subjects=["the designer", "the model", "the stylist", "the fashion house"],
        verbs=["unveiled", "styled", "sketched", "showcased", "redesigned"],
        objects=["the summer collection", "the runway show", "the evening gown", "the new fabric line"],
        adjectives=["elegant", "bold", "minimalist", "vibrant", "timeless"],
    ),
    "fitness": dict(
        subjects=["the trainer", "the athlete", "the gym member", "the physiotherapist"],
        verbs=["demonstrated", "recommended", "adjusted", "tracked progress on"],
        objects=["the workout routine", "the strength training plan", "the recovery exercises", "the nutrition plan"],
        adjectives=["intense", "gentle", "structured", "effective", "exhausting"],
    ),
    "history": dict(
        subjects=["the historian", "the archaeologist", "the museum curator", "the researcher"],
        verbs=["documented", "uncovered", "restored", "studied", "dated"],
        objects=["the ancient ruins", "the historical manuscript", "the buried artefact", "the old fortress"],
        adjectives=["ancient", "well-preserved", "forgotten", "significant", "mysterious"],
    ),
    "art": dict(
        subjects=["the painter", "the sculptor", "the gallery owner", "the art critic"],
        verbs=["displayed", "restored", "sketched", "auctioned", "interpreted"],
        objects=["the abstract painting", "the marble sculpture", "the modern art exhibit", "the museum collection"],
        adjectives=["striking", "abstract", "delicate", "provocative", "timeless"],
    ),
    "science": dict(
        subjects=["the scientist", "the laboratory team", "the physicist", "the biologist"],
        verbs=["measured", "hypothesised about", "published findings on", "tested", "modelled"],
        objects=["the chemical reaction", "the genetic sample", "the experimental data", "the new compound"],
        adjectives=["groundbreaking", "inconclusive", "precise", "surprising", "peer-reviewed"],
    ),
    "business": dict(
        subjects=["the ceo", "the manager", "the company", "the marketing team"],
        verbs=["launched", "restructured", "acquired", "negotiated", "announced"],
        objects=["the merger deal", "the product launch", "the annual report", "the new branch office"],
        adjectives=["strategic", "ambitious", "costly", "successful", "delayed"],
    ),
    "cars": dict(
        subjects=["the mechanic", "the driver", "the car manufacturer", "the engineer"],
        verbs=["repaired", "test-drove", "designed", "recalled", "unveiled"],
        objects=["the electric vehicle", "the engine assembly", "the new sedan model", "the racing car"],
        adjectives=["fuel-efficient", "high-performance", "outdated", "sleek", "reliable"],
    ),
    "photography": dict(
        subjects=["the photographer", "the editor", "the tourist", "the wildlife photographer"],
        verbs=["captured", "edited", "framed", "printed", "shared"],
        objects=["the sunset landscape", "the portrait shot", "the street photo series", "the wildlife image"],
        adjectives=["stunning", "grainy", "well-lit", "candid", "vivid"],
    ),
    "gaming": dict(
        subjects=["the game developer", "the player", "the streamer", "the game studio"],
        verbs=["released", "reviewed", "patched", "designed", "livestreamed"],
        objects=["the new video game", "the game update", "the multiplayer mode", "the game trailer"],
        adjectives=["addictive", "buggy", "immersive", "fast-paced", "underrated"],
    ),
    "health": dict(
        subjects=["the nutritionist", "the therapist", "the public health official", "the researcher"],
        verbs=["advised", "studied", "warned about", "recommended"],
        objects=["the balanced diet", "the sleep schedule", "the mental health survey", "the vaccination programme"],
        adjectives=["essential", "overlooked", "beneficial", "concerning", "widespread"],
    ),
    "environment": dict(
        subjects=["the environmentalist", "the government agency", "the scientist", "the community"],
        verbs=["monitored", "reported on", "campaigned against", "restored"],
        objects=["the deforestation rate", "the plastic pollution", "the wetland habitat", "the carbon emissions"],
        adjectives=["alarming", "reversible", "widespread", "long-term", "urgent"],
    ),
    "literature": dict(
        subjects=["the author", "the poet", "the editor", "the literary critic"],
        verbs=["published", "reviewed", "translated", "revised", "drafted"],
        objects=["the debut novel", "the poetry collection", "the short story", "the memoir"],
        adjectives=["moving", "dense", "lyrical", "overlong", "compelling"],
    ),
    "architecture": dict(
        subjects=["the architect", "the city planner", "the construction firm", "the engineer"],
        verbs=["designed", "renovated", "approved", "sketched plans for"],
        objects=["the office tower", "the public library", "the residential complex", "the historic bridge"],
        adjectives=["modern", "sustainable", "imposing", "elegant", "functional"],
    ),
    "psychology": dict(
        subjects=["the psychologist", "the researcher", "the therapist", "the university study"],
        verbs=["examined", "surveyed", "measured", "explained"],
        objects=["the effects of stress", "the sleep patterns", "the decision-making process", "the childhood development study"],
        adjectives=["surprising", "consistent", "subtle", "well-documented"],
    ),
    "agriculture": dict(
        subjects=["the farmer", "the agronomist", "the cooperative", "the researcher"],
        verbs=["harvested", "irrigated", "planted", "monitored"],
        objects=["the wheat field", "the rice paddy", "the orchard", "the soil quality"],
        adjectives=["fertile", "drought-affected", "abundant", "sustainable"],
    ),
    "aviation": dict(
        subjects=["the pilot", "the airline", "the air traffic controller", "the aircraft engineer"],
        verbs=["inspected", "delayed", "rerouted", "landed", "cleared for takeoff"],
        objects=["the passenger jet", "the cargo flight", "the runway", "the flight schedule"],
        adjectives=["delayed", "smooth", "turbulent", "on-time", "overbooked"],
    ),
    "chemistry": dict(
        subjects=["the chemist", "the laboratory", "the research team", "the student"],
        verbs=["synthesised", "titrated", "analysed", "purified"],
        objects=["the chemical compound", "the reaction mixture", "the lab sample", "the catalyst"],
        adjectives=["stable", "volatile", "concentrated", "diluted"],
    ),
    "economy": dict(
        subjects=["the economist", "the central bank", "the government", "the trade ministry"],
        verbs=["forecasted", "adjusted", "reported", "debated"],
        objects=["the inflation rate", "the unemployment figures", "the trade deficit", "the national budget"],
        adjectives=["sluggish", "robust", "unstable", "improving"],
    ),
    "religion": dict(
        subjects=["the scholar", "the community elder", "the pilgrim", "the historian"],
        verbs=["studied", "described", "documented", "translated"],
        objects=["the ancient text", "the religious festival", "the sacred site", "the traditional ceremony"],
        adjectives=["sacred", "ancient", "solemn", "widely observed"],
    ),
    "mythology": dict(
        subjects=["the folklorist", "the storyteller", "the researcher", "the anthropologist"],
        verbs=["retold", "documented", "compared", "traced the origins of"],
        objects=["the ancient legend", "the folk tale", "the creation myth", "the local folklore"],
        adjectives=["legendary", "ancient", "widespread", "obscure"],
    ),
    "mathematics": dict(
        subjects=["the mathematician", "the student", "the research group", "the professor"],
        verbs=["proved", "solved", "generalised", "disproved"],
        objects=["the conjecture", "the differential equation", "the geometric problem", "the algorithm's complexity"],
        adjectives=["elegant", "unsolved", "complex", "surprising"],
    ),
    "geography": dict(
        subjects=["the geographer", "the surveyor", "the researcher", "the cartographer"],
        verbs=["mapped", "measured", "surveyed", "studied"],
        objects=["the river delta", "the mountain range", "the coastal erosion", "the urban sprawl"],
        adjectives=["vast", "shifting", "rugged", "densely populated"],
    ),
    "sociology": dict(
        subjects=["the sociologist", "the survey team", "the researcher", "the community organiser"],
        verbs=["studied", "surveyed", "documented", "analysed"],
        objects=["the social inequality", "the neighbourhood demographics", "the migration patterns", "the community survey"],
        adjectives=["widening", "persistent", "notable", "understudied"],
    ),
    "linguistics": dict(
        subjects=["the linguist", "the translator", "the researcher", "the language teacher"],
        verbs=["analysed", "documented", "compared", "translated"],
        objects=["the regional dialect", "the grammar structure", "the endangered language", "the pronunciation pattern"],
        adjectives=["endangered", "distinct", "evolving", "widely spoken"],
    ),
    "robotics": dict(
        subjects=["the robotics engineer", "the research lab", "the startup", "the student team"],
        verbs=["built", "programmed", "tested", "demonstrated"],
        objects=["the autonomous robot", "the robotic arm", "the navigation system", "the sensor array"],
        adjectives=["autonomous", "precise", "experimental", "reliable"],
    ),
    "cybersecurity": dict(
        subjects=["the security analyst", "the company", "the researcher", "the hacker group"],
        verbs=["detected", "patched", "investigated", "reported"],
        objects=["the data breach", "the software vulnerability", "the phishing campaign", "the network intrusion"],
        adjectives=["critical", "widespread", "unpatched", "targeted"],
    ),
}

TEMPLATES = [
    "{subject} {verb} {object}.",
    "Yesterday, {subject} {verb} {object}.",
    "{subject} {verb} the {adjective} {object_noun}.",
    "According to reports, {subject} {verb} {object}.",
    "In a surprising turn, {subject} {verb} {object}.",
    "{subject} carefully {verb} {object}, calling it {adjective}.",
]


def strip_the(phrase):
    """'the electric vehicle' -> 'electric vehicle', for templates that
    already supply their own article."""
    return phrase[4:] if phrase.startswith("the ") else phrase


def generate_sentence(topic_name, bank, rng):
    subject = rng.choice(bank["subjects"])
    verb = rng.choice(bank["verbs"])
    obj = rng.choice(bank["objects"])
    adjective = rng.choice(bank["adjectives"])
    template = rng.choice(TEMPLATES)
    sentence = template.format(
        subject=subject.capitalize() if template.startswith("{subject}") else subject,
        verb=verb,
        object=obj,
        object_noun=strip_the(obj),
        adjective=adjective,
    )
    return sentence


def build_corpus(n_sentences, seed):
    rng = random.Random(seed)
    topic_names = list(TOPICS.keys())
    seen = set()
    corpus = []
    while len(corpus) < n_sentences:
        topic = rng.choice(topic_names)
        sentence = generate_sentence(topic, TOPICS[topic], rng)
        # small amount of dedup so we don't store thousands of identical
        # copies of a sentence; a handful of repeats across topics is fine
        key = sentence
        if key in seen and rng.random() < 0.9:
            continue
        seen.add(key)
        corpus.append({"text": sentence, "topic": topic})
    return corpus


def main():
    os.makedirs(DATA_DIR, exist_ok=True)

    print(f"Generating {N_SENTENCES} sentences across {len(TOPICS)} topics ...")
    corpus = build_corpus(N_SENTENCES, SEED)
    texts = [row["text"] for row in corpus]
    print(f"Generated {len(texts)} sentences.")

    print("Fitting TF-IDF + TruncatedSVD embedder ...")
    tfidf = TfidfVectorizer(max_features=20000, ngram_range=(1, 2))
    tfidf_matrix = tfidf.fit_transform(texts)

    svd = TruncatedSVD(n_components=EMBED_DIM, random_state=SEED)
    embeddings = svd.fit_transform(tfidf_matrix).astype(np.float32)
    print(f"Embeddings shape: {embeddings.shape}")

    # ------------------------------------------------------------------
    # carve out the held-out query set BEFORE assigning final ids, so
    # queries are a separate set of sentences, not copies of stored ones
    # ------------------------------------------------------------------
    rng = np.random.default_rng(SEED)
    all_idx = np.arange(len(texts))
    rng.shuffle(all_idx)
    query_idx = all_idx[:N_QUERIES]
    store_idx = all_idx[N_QUERIES:]

    store_texts = [corpus[i] for i in store_idx]
    store_embeddings = embeddings[store_idx]
    ids = np.arange(len(store_idx), dtype=np.int64)

    query_texts = [corpus[i]["text"] for i in query_idx]
    query_embeddings = embeddings[query_idx]

    print(f"Stored vectors: {len(ids)}   Held-out queries: {len(query_texts)}")

    # ------------------------------------------------------------------
    # ground truth: exact top-10 for every query, via brute force
    # ------------------------------------------------------------------
    print("Computing exact ground-truth top-10 neighbours for every query ...")
    exact_index = BruteForceIndex(EMBED_DIM)
    exact_index.insert_batch(store_embeddings, ids=ids.tolist())

    ground_truth = np.zeros((N_QUERIES, 10), dtype=np.int64)
    for i, q in enumerate(query_embeddings):
        results = exact_index.search(q, k=10)
        result_ids = [r[0] for r in results]
        while len(result_ids) < 10:
            result_ids.append(-1)
        ground_truth[i] = result_ids

    # ------------------------------------------------------------------
    # write everything out
    # ------------------------------------------------------------------
    with open(os.path.join(DATA_DIR, "corpus.json"), "w") as f:
        json.dump(
            [{"id": int(i), **row} for i, row in zip(ids, store_texts)],
            f,
        )

    np.save(os.path.join(DATA_DIR, "embeddings.npy"), store_embeddings.astype(np.float32))

    with open(os.path.join(DATA_DIR, "query_texts.json"), "w") as f:
        json.dump(query_texts, f)

    np.save(os.path.join(DATA_DIR, "query_embeddings.npy"), query_embeddings.astype(np.float32))
    np.save(os.path.join(DATA_DIR, "ground_truth.npy"), ground_truth)

    with open(os.path.join(DATA_DIR, "embedder.pkl"), "wb") as f:
        pickle.dump({"tfidf": tfidf, "svd": svd}, f)

    print("\nDone. Files written to", DATA_DIR)
    for fn in [
        "corpus.json", "embeddings.npy", "query_texts.json",
        "query_embeddings.npy", "ground_truth.npy", "embedder.pkl",
    ]:
        path = os.path.join(DATA_DIR, fn)
        size_kb = os.path.getsize(path) / 1024
        print(f"  {fn:24s} {size_kb:10.1f} KB")


if __name__ == "__main__":
    main()
