"""
STEP 4 of the pipeline. This is the script you use for the demo video.

Loads the built VectorDB and the fitted embedder, then lets you type any
sentence and see the best matching sentences from the corpus, from both
the exact index and the approximate index, side by side.

It also supports --insert and --delete so you can show the CRUD part of
the API working, not just search.

Usage:
    # interactive mode, keeps asking for a new sentence until you type
    # "exit"
    python scripts/demo_query.py

    # one-shot query
    python scripts/demo_query.py --query "the striker scored a goal"

    # insert a brand new sentence into the running database, then search
    # for it to prove it is actually findable. By default this does NOT
    # change the file on disk, it only proves insert works for this run.
    # Add --save if you want the change to persist for later runs.
    python scripts/demo_query.py --insert "The robot vacuum cleaned the living room." --save

    # delete a vector by id (ids are printed next to every search result)
    python scripts/demo_query.py --delete 1234 --save

    # one process, one clean demo of the whole CRUD API: insert a
    # sentence, prove it shows up in search, delete it, prove it is gone.
    # This is the easiest single command to record for a demo video.
    python scripts/demo_query.py --live-demo
"""

import argparse
import json
import os
import pickle
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "..", "artifacts")


def load_everything():
    db_path = os.path.join(ARTIFACT_DIR, "vector_db.pkl")
    embedder_path = os.path.join(DATA_DIR, "embedder.pkl")
    corpus_path = os.path.join(DATA_DIR, "corpus.json")

    for path, hint in [
        (db_path, "python scripts/build_and_save.py"),
        (embedder_path, "python scripts/generate_data.py"),
        (corpus_path, "python scripts/generate_data.py"),
    ]:
        if not os.path.exists(path):
            raise SystemExit(f"Missing {path}. Run: {hint}")

    with open(db_path, "rb") as f:
        db = pickle.load(f)
    with open(embedder_path, "rb") as f:
        embedder = pickle.load(f)
    with open(corpus_path) as f:
        corpus_rows = json.load(f)

    id_to_text = {row["id"]: row["text"] for row in corpus_rows}
    return db, embedder, id_to_text


def embed_sentence(embedder, sentence):
    tfidf_vec = embedder["tfidf"].transform([sentence])
    vec = embedder["svd"].transform(tfidf_vec)[0]
    return vec.astype(np.float32)


def run_query(db, embedder, id_to_text, sentence, k=10):
    vec = embed_sentence(embedder, sentence)

    t0 = time.perf_counter()
    exact_results = db.exact.search(vec, k=k)
    exact_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    approx_results = db.approx.search(vec, k=k)
    approx_ms = (time.perf_counter() - t0) * 1000

    print(f"\nQuery: \"{sentence}\"")
    print(f"\n[Exact / brute-force index]   ({exact_ms:.3f} ms)")
    for rank, (vid, score) in enumerate(exact_results, 1):
        text = id_to_text.get(vid, "<deleted or unknown id>")
        print(f"  {rank:2d}. id={vid:<7d} score={score:.4f}  {text}")

    print(f"\n[Approximate / IVF-Flat index] ({approx_ms:.3f} ms)")
    for rank, (vid, score) in enumerate(approx_results, 1):
        text = id_to_text.get(vid, "<deleted or unknown id>")
        print(f"  {rank:2d}. id={vid:<7d} score={score:.4f}  {text}")


def save_db(db):
    db_path = os.path.join(ARTIFACT_DIR, "vector_db.pkl")
    with open(db_path, "wb") as f:
        pickle.dump(db, f)
    print(f"Saved updated index back to {db_path}")


def live_demo(db, embedder, id_to_text, k=10):
    """One process, no persistence needed: insert a brand new sentence,
    prove it is findable, delete it again, prove it is gone. This is the
    simplest single command that shows the whole insert/search/delete API
    actually working end to end."""
    sentence = "The robot vacuum cleaned the living room carpet."
    print("STEP A: inserting a brand new sentence that was never in the corpus:")
    print(f'  "{sentence}"')
    vec = embed_sentence(embedder, sentence)
    new_id = db.insert(vec)
    id_to_text[new_id] = sentence
    print(f"  -> inserted with id={new_id}\n")

    print("STEP B: searching for it, it should come back as the #1 result "
          "with a similarity score of 1.0 on both indexes:")
    run_query(db, embedder, id_to_text, sentence, k=k)

    print(f"\nSTEP C: deleting id={new_id} from both indexes ...")
    db.delete(new_id)
    del id_to_text[new_id]
    print("  -> deleted\n")

    print("STEP D: searching for the exact same sentence again. The deleted "
          "id must NOT appear anywhere in the results this time:")
    run_query(db, embedder, id_to_text, sentence, k=k)

    top_exact_ids = [r[0] for r in db.exact.search(vec, k=k)]
    top_approx_ids = [r[0] for r in db.approx.search(vec, k=k)]
    if new_id not in top_exact_ids and new_id not in top_approx_ids:
        print(f"\nCheck passed: id={new_id} is gone from both indexes after delete.")
    else:
        print(f"\nCheck FAILED: id={new_id} still showed up after delete.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", type=str, help="Run a single query and exit.")
    parser.add_argument("--insert", type=str, help="Insert a new sentence, then search for it.")
    parser.add_argument("--delete", type=int, help="Delete a vector by its id.")
    parser.add_argument("--save", action="store_true",
                         help="Write the change from --insert/--delete back to artifacts/vector_db.pkl.")
    parser.add_argument("--live-demo", action="store_true",
                         help="Run insert -> search -> delete -> search in one process, no --save needed.")
    parser.add_argument("--k", type=int, default=10, help="How many results to return (default 10).")
    args = parser.parse_args()

    db, embedder, id_to_text = load_everything()

    if args.live_demo:
        live_demo(db, embedder, id_to_text, k=args.k)
        return

    if args.delete is not None:
        try:
            db.delete(args.delete)
            print(f"Deleted id {args.delete} from both indexes.")
            if args.save:
                save_db(db)
            else:
                print("(This was not saved. Add --save to make it permanent.)")
        except KeyError as e:
            print(f"Could not delete: {e}")
        return

    if args.insert is not None:
        vec = embed_sentence(embedder, args.insert)
        new_id = db.insert(vec)
        id_to_text[new_id] = args.insert
        print(f"Inserted \"{args.insert}\" with new id={new_id}")
        run_query(db, embedder, id_to_text, args.insert, k=args.k)
        if args.save:
            save_db(db)
        else:
            print("(This was not saved. Add --save to make it permanent.)")
        return

    if args.query is not None:
        run_query(db, embedder, id_to_text, args.query, k=args.k)
        return

    # interactive mode
    print("Type any sentence to search for its closest matches.")
    print("Type 'exit' or press Ctrl+C to quit.\n")
    while True:
        try:
            sentence = input("query> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not sentence:
            continue
        if sentence.lower() in ("exit", "quit"):
            break
        if sentence.startswith("-"):
            # someone typed a command-line flag (like --insert or --delete)
            # into the search prompt by mistake. This prompt only accepts
            # plain sentences, so catch this and point them to the right
            # place instead of quietly searching for the flag as text.
            print(
                "\nThat looks like a command-line option, not a sentence to "
                "search for. This prompt only searches for plain text.\n"
                "Type 'exit' first to leave this prompt, then run it as a "
                "new command, for example:\n"
                f'  python scripts/demo_query.py {sentence}\n'
            )
            continue
        run_query(db, embedder, id_to_text, sentence, k=args.k)


if __name__ == "__main__":
    main()
