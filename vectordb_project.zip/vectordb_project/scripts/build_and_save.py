"""
STEP 2 of the pipeline.

Loads the embeddings produced by generate_data.py, builds a VectorDB
(both the exact brute-force index and the trained IVF-Flat index), and
pickles the whole thing to disk so the benchmark script and the demo
script can just load it back instead of rebuilding it every time.

Run:
    python scripts/build_and_save.py

Reads from ./data/:
    embeddings.npy

Writes to ./artifacts/:
    vector_db.pkl   - the fully built VectorDB object (both indexes,
                       already trained and loaded with all 54,500+ vectors)
"""

import os
import pickle
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from vectordb import VectorDB  # noqa: E402

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "..", "artifacts")

EMBED_DIM = 128
NLIST = 256     # number of IVF clusters. Rule of thumb: roughly sqrt(N)
NPROBE = 8      # number of clusters searched per query


def main():
    os.makedirs(ARTIFACT_DIR, exist_ok=True)

    embeddings_path = os.path.join(DATA_DIR, "embeddings.npy")
    if not os.path.exists(embeddings_path):
        raise SystemExit(
            "data/embeddings.npy not found. Run scripts/generate_data.py first."
        )

    embeddings = np.load(embeddings_path)
    n, dim = embeddings.shape
    print(f"Loaded {n} vectors of dimension {dim}")

    db = VectorDB(dim=dim, nlist=NLIST, nprobe=NPROBE, seed=42)

    print(f"Training IVF-Flat (nlist={NLIST}) on all {n} vectors ...")
    t0 = time.time()
    assignments = db.train_approx(embeddings, n_iter=20, verbose=True)
    print(f"Training took {time.time() - t0:.2f}s")

    print("Bulk loading vectors into both indexes ...")
    t0 = time.time()
    ids = list(range(n))
    db.bulk_load(embeddings, ids=ids, assignments=assignments)
    print(f"Bulk load took {time.time() - t0:.2f}s")

    print(f"Exact index size: {len(db.exact)}")
    print(f"Approx index size: {len(db.approx)}")

    out_path = os.path.join(ARTIFACT_DIR, "vector_db.pkl")
    with open(out_path, "wb") as f:
        pickle.dump(db, f)

    size_mb = os.path.getsize(out_path) / (1024 * 1024)
    print(f"\nSaved built index to {out_path} ({size_mb:.1f} MB)")


if __name__ == "__main__":
    main()
