"""
STEP 3 of the pipeline.

Loads the built VectorDB (artifacts/vector_db.pkl) and the 500 held-out
queries with their exact ground truth (data/query_embeddings.npy,
data/ground_truth.npy), then:

1. Runs every query through the exact brute-force index and times it.
2. Runs every query through the approximate IVF-Flat index and times it.
3. Compares IVF-Flat's top-10 results against the ground truth top-10 to
   compute recall@10 -- i.e. "out of the true top-10 neighbours, what
   fraction did the approximate index actually find?"
4. Prints a report, and also saves it to results/benchmark_report.txt so
   it does not just scroll off the terminal.

This is the script that actually answers the question the whole project
is about: "how much accuracy do you give up by using an approximate
index, and how much speed do you get back for it?"

Run:
    python scripts/benchmark.py
"""

import os
import pickle
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "..", "artifacts")
RESULTS_DIR = os.path.join(os.path.dirname(__file__), "..", "results")


def recall_at_10(predicted_ids, true_ids):
    """Fraction of true_ids that appear anywhere in predicted_ids."""
    true_set = set(t for t in true_ids if t != -1)
    if not true_set:
        return 1.0
    predicted_set = set(predicted_ids)
    return len(true_set & predicted_set) / len(true_set)


def main():
    db_path = os.path.join(ARTIFACT_DIR, "vector_db.pkl")
    if not os.path.exists(db_path):
        raise SystemExit(
            "artifacts/vector_db.pkl not found. Run scripts/build_and_save.py first."
        )

    with open(db_path, "rb") as f:
        db = pickle.load(f)

    query_embeddings = np.load(os.path.join(DATA_DIR, "query_embeddings.npy"))
    ground_truth = np.load(os.path.join(DATA_DIR, "ground_truth.npy"))
    n_queries = len(query_embeddings)

    print(f"Loaded index with {len(db.exact)} vectors.")
    print(f"Running benchmark over {n_queries} held-out queries ...\n")

    exact_times = []
    approx_times = []
    recalls = []

    for i in range(n_queries):
        q = query_embeddings[i]

        t0 = time.perf_counter()
        exact_results = db.exact.search(q, k=10)
        exact_times.append(time.perf_counter() - t0)

        t0 = time.perf_counter()
        approx_results = db.approx.search(q, k=10)
        approx_times.append(time.perf_counter() - t0)

        approx_ids = [r[0] for r in approx_results]
        recalls.append(recall_at_10(approx_ids, ground_truth[i]))

    exact_times = np.array(exact_times) * 1000    # -> milliseconds
    approx_times = np.array(approx_times) * 1000
    recalls = np.array(recalls)

    speedup = exact_times.mean() / approx_times.mean()

    lines = []
    lines.append("=" * 60)
    lines.append("VECTOR DATABASE BENCHMARK REPORT")
    lines.append("=" * 60)
    lines.append(f"Vectors indexed        : {len(db.exact)}")
    lines.append(f"Vector dimension        : {db.dim}")
    lines.append(f"Queries run             : {n_queries}")
    lines.append(f"IVF nlist / nprobe      : {db.approx.nlist} / {db.approx.nprobe}")
    lines.append("")
    lines.append("-- Latency (per single query, milliseconds) --")
    lines.append(f"Exact  (brute force)    : mean={exact_times.mean():.3f}  "
                  f"p50={np.median(exact_times):.3f}  p95={np.percentile(exact_times, 95):.3f}")
    lines.append(f"Approx (IVF-Flat)       : mean={approx_times.mean():.3f}  "
                  f"p50={np.median(approx_times):.3f}  p95={np.percentile(approx_times, 95):.3f}")
    lines.append(f"Speedup (exact/approx)  : {speedup:.2f}x")
    lines.append("")
    lines.append("-- Accuracy --")
    lines.append(f"Recall@10 mean          : {recalls.mean():.4f}")
    lines.append(f"Recall@10 min           : {recalls.min():.4f}")
    lines.append(f"Recall@10 queries == 1.0: {(recalls == 1.0).sum()} / {n_queries} "
                 f"({100 * (recalls == 1.0).mean():.1f}%)")
    lines.append("=" * 60)

    report = "\n".join(lines)
    print(report)

    os.makedirs(RESULTS_DIR, exist_ok=True)
    out_path = os.path.join(RESULTS_DIR, "benchmark_report.txt")
    with open(out_path, "w") as f:
        f.write(report + "\n")
    print(f"\nReport also saved to {out_path}")


if __name__ == "__main__":
    main()
