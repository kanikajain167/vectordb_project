"""
Unit tests for the vectordb package.

Run with:
    pytest tests/ -v

These do not use the big 54,500-vector data set (that would make tests
slow); instead they build small, controlled sets of random vectors so
each test is fast and its expected answer can be checked by hand /
with plain numpy.
"""

import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from vectordb.brute_force import BruteForceIndex
from vectordb.ivf_flat import IVFFlatIndex
from vectordb.api import VectorDB
from vectordb.kmeans import kmeans


DIM = 16


def random_vectors(n, dim=DIM, seed=0):
    rng = np.random.default_rng(seed)
    return rng.normal(size=(n, dim)).astype(np.float32)


# ---------------------------------------------------------------------
# BruteForceIndex
# ---------------------------------------------------------------------

def test_brute_force_insert_and_search_finds_itself():
    idx = BruteForceIndex(DIM)
    vectors = random_vectors(200)
    idx.insert_batch(vectors)

    # searching with a stored vector as the query must return that same
    # vector as the #1 result with score ~1.0 (cosine similarity with
    # itself, after normalisation)
    query = vectors[42]
    results = idx.search(query, k=5)
    assert results[0][0] == 42
    assert results[0][1] == pytest.approx(1.0, abs=1e-4)


def test_brute_force_matches_manual_cosine_ranking():
    idx = BruteForceIndex(DIM)
    vectors = random_vectors(300, seed=1)
    idx.insert_batch(vectors)

    query = random_vectors(1, seed=2)[0]

    # compute the "obviously correct" answer directly with numpy, then
    # compare against what the index returns
    norm_vectors = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
    norm_query = query / np.linalg.norm(query)
    expected_scores = norm_vectors @ norm_query
    expected_top5 = list(np.argsort(-expected_scores)[:5])

    results = idx.search(query, k=5)
    got_top5 = [r[0] for r in results]

    assert got_top5 == expected_top5


def test_brute_force_delete_removes_vector_from_results():
    idx = BruteForceIndex(DIM)
    vectors = random_vectors(50, seed=3)
    idx.insert_batch(vectors)

    target_id = 7
    query = vectors[target_id]
    results_before = idx.search(query, k=1)
    assert results_before[0][0] == target_id

    idx.delete(target_id)
    results_after = idx.search(query, k=50)
    returned_ids = [r[0] for r in results_after]
    assert target_id not in returned_ids
    assert len(idx) == 49


def test_brute_force_delete_missing_id_raises():
    idx = BruteForceIndex(DIM)
    idx.insert_batch(random_vectors(5, seed=4))
    with pytest.raises(KeyError):
        idx.delete(999)


def test_brute_force_insert_after_delete_reuses_structure_correctly():
    idx = BruteForceIndex(DIM)
    idx.insert_batch(random_vectors(10, seed=5))
    idx.delete(3)
    new_vec = random_vectors(1, seed=6)[0]
    new_id = idx.insert(new_vec)
    results = idx.search(new_vec, k=1)
    assert results[0][0] == new_id
    assert len(idx) == 10  # 10 - 1 deleted + 1 inserted


# ---------------------------------------------------------------------
# kmeans
# ---------------------------------------------------------------------

def test_kmeans_produces_requested_number_of_clusters_and_covers_all_points():
    vectors = random_vectors(400, seed=7)
    vectors = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
    centroids, assignments = kmeans(vectors, k=10, n_iter=15, seed=7)
    assert centroids.shape == (10, DIM)
    assert assignments.shape == (400,)
    assert set(assignments.tolist()).issubset(set(range(10)))
    # every point must have been assigned, none left as the -1 placeholder
    assert (assignments >= 0).all()


def test_kmeans_rejects_k_bigger_than_dataset():
    vectors = random_vectors(5, seed=8)
    with pytest.raises(ValueError):
        kmeans(vectors, k=10)


# ---------------------------------------------------------------------
# IVFFlatIndex
# ---------------------------------------------------------------------

def test_ivf_requires_training_before_use():
    idx = IVFFlatIndex(DIM, nlist=4, nprobe=2)
    with pytest.raises(RuntimeError):
        idx.insert(random_vectors(1, seed=9)[0])
    with pytest.raises(RuntimeError):
        idx.search(random_vectors(1, seed=9)[0])


def test_ivf_insert_and_search_finds_itself():
    vectors = random_vectors(500, seed=10)
    idx = IVFFlatIndex(DIM, nlist=16, nprobe=16, seed=10)  # nprobe==nlist -> exhaustive
    assignments = idx.train(vectors, n_iter=15)
    idx.insert_batch(vectors, assignments=assignments)

    query = vectors[100]
    results = idx.search(query, k=1)
    assert results[0][0] == 100
    assert results[0][1] == pytest.approx(1.0, abs=1e-4)


def test_ivf_delete_removes_vector_from_results():
    vectors = random_vectors(500, seed=11)
    idx = IVFFlatIndex(DIM, nlist=16, nprobe=16, seed=11)
    assignments = idx.train(vectors, n_iter=15)
    idx.insert_batch(vectors, assignments=assignments)

    target_id = 200
    query = vectors[target_id]
    idx.delete(target_id)
    results = idx.search(query, k=500)
    returned_ids = [r[0] for r in results]
    assert target_id not in returned_ids
    assert len(idx) == 499


def test_ivf_delete_missing_id_raises():
    vectors = random_vectors(50, seed=12)
    idx = IVFFlatIndex(DIM, nlist=4, nprobe=4, seed=12)
    assignments = idx.train(vectors, n_iter=10)
    idx.insert_batch(vectors, assignments=assignments)
    with pytest.raises(KeyError):
        idx.delete(9999)


def test_ivf_with_full_nprobe_has_high_recall_against_brute_force():
    """With nprobe == nlist, IVF-Flat searches every cluster, so it should
    return exactly the same top-k as brute force (same set of ids, maybe
    different float rounding, so we only compare ids)."""
    vectors = random_vectors(1000, seed=13)

    exact = BruteForceIndex(DIM)
    exact.insert_batch(vectors)

    ivf = IVFFlatIndex(DIM, nlist=20, nprobe=20, seed=13)
    assignments = ivf.train(vectors, n_iter=15)
    ivf.insert_batch(vectors, assignments=assignments)

    query = random_vectors(1, seed=14)[0]
    exact_ids = set(r[0] for r in exact.search(query, k=10))
    ivf_ids = set(r[0] for r in ivf.search(query, k=10))
    assert exact_ids == ivf_ids


# ---------------------------------------------------------------------
# VectorDB (the combined API)
# ---------------------------------------------------------------------

def test_vectordb_bulk_load_keeps_both_indexes_in_sync():
    vectors = random_vectors(300, seed=15)
    db = VectorDB(DIM, nlist=10, nprobe=10, seed=15)
    assignments = db.train_approx(vectors, n_iter=10)
    db.bulk_load(vectors, assignments=assignments)
    assert len(db.exact) == 300
    assert len(db.approx) == 300


def test_vectordb_insert_is_findable_on_both_backends():
    vectors = random_vectors(300, seed=16)
    db = VectorDB(DIM, nlist=10, nprobe=10, seed=16)
    assignments = db.train_approx(vectors, n_iter=10)
    db.bulk_load(vectors, assignments=assignments)

    new_vec = random_vectors(1, seed=17)[0]
    new_id = db.insert(new_vec)

    result = db.search(new_vec, k=1, backend="both")
    assert result["exact"][0][0] == new_id
    assert result["approx"][0][0] == new_id


def test_vectordb_delete_removes_from_both_backends():
    vectors = random_vectors(300, seed=18)
    db = VectorDB(DIM, nlist=10, nprobe=10, seed=18)
    assignments = db.train_approx(vectors, n_iter=10)
    db.bulk_load(vectors, assignments=assignments)

    target_id = 55
    query = vectors[target_id]
    db.delete(target_id)

    result = db.search(query, k=300, backend="both")
    exact_ids = [r[0] for r in result["exact"]]
    approx_ids = [r[0] for r in result["approx"]]
    assert target_id not in exact_ids
    assert target_id not in approx_ids
    assert len(db) == 299
