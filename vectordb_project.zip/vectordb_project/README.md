# Write the Vector Database Yourself

This is my submission for the task "Write the Vector Database Yourself".
The task was to not use any ready made vector database library like
Pinecone, FAISS, Chroma or sklearn.neighbors, and instead build one myself
using numpy, so that I actually understand what happens inside a vector
database instead of just importing one.

(If you are looking for step by step commands to actually run this
project, that is in a separate file called `HOW_TO_RUN.md`, I kept it
separate from this file on purpose.)

## What I built

1. **An exact brute force index** - checks a query against every single
   stored vector using cosine similarity, so it always gives the correct
   answer. This is slow once data gets large (it has to check everything),
   but because it's always correct, I use it as the "ground truth" to
   check my other index against.

2. **An approximate index called IVF-Flat, built from scratch** - first
   all vectors get grouped into clusters using k-means (I wrote k-means
   myself too, this is not sklearn's KMeans), and when a query comes in,
   only the few nearest clusters are searched instead of the whole
   dataset. This makes search faster, but it can occasionally miss a
   correct answer, which is why it's called "approximate" instead of
   "exact".

3. **A small unified API** on top of both indexes, with insert, search
   (top-k) and delete, so both indexes stay in sync with each other and
   can be compared directly against each other.

4. A **data pipeline** that generates 55,000+ short text sentences from 40
   different topics (sports, cooking, finance, medicine, space etc.),
   converts them into 128-dimension vectors using TF-IDF + SVD, and sets
   aside 500 sentences as test queries with their exact top-10 ground
   truth answers already computed.

5. A **benchmark script** that runs all 500 test queries through both
   indexes and reports the speed difference and the accuracy (recall@10)
   of the approximate index compared to the exact one.

6. A small **demo script** so anyone can type any sentence and see the
   closest matches live, plus a one-command demo that shows insert,
   search and delete all working together.

7. **Automated tests** written using pytest (15 tests) that check
   insert/search/delete actually work correctly on both indexes, not
   just tested by eye by running the scripts.

## Results I got

On my machine, with 54,500 vectors of 128 dimensions:

| Metric | Exact (brute force) | Approximate (IVF-Flat) |
|---|---|---|
| Mean latency per query | ~1.3 ms | ~0.65 ms |
| Recall@10 (vs ground truth) | 100% (it is the ground truth) | ~98.5% |

So the approximate index is roughly 2x faster while still finding about
98.5% of the true nearest neighbours on average. This is the core
speed-vs-accuracy tradeoff the assignment wanted me to actually measure,
not just describe.

(With only ~54K vectors, brute force itself is still fast on a modern
CPU, which is why the speedup here is "only" 2x. On datasets with
millions of vectors, brute force time grows directly with the number of
vectors, while IVF-Flat keeps searching only a handful of clusters
regardless, so the gap would be much bigger.)

## Folder structure

```
vectordb_project/
|
|-- README.md                 <- this file (project overview)
|-- HOW_TO_RUN.md              <- step by step commands to run everything
|-- requirements.txt          <- python libraries needed
|
|-- vectordb/                 <- the actual vector database code
|   |-- __init__.py
|   |-- brute_force.py        <- exact index (ground truth)
|   |-- kmeans.py             <- k-means clustering, written from scratch
|   |-- ivf_flat.py           <- approximate index, built using kmeans.py
|   |-- api.py                <- VectorDB class, single API over both indexes
|
|-- scripts/                  <- pipeline scripts, see HOW_TO_RUN.md for order
|   |-- generate_data.py      <- makes the text data + vectors + test queries
|   |-- build_and_save.py     <- builds the actual indexes and saves them
|   |-- benchmark.py          <- compares exact vs approximate index
|   |-- demo_query.py         <- try out the database / live insert-search-delete demo
|
|-- tests/
|   |-- test_indexes.py       <- automated tests (pytest) for both indexes and the API
|
|-- data/            <- NOT in the zip, gets auto-created when scripts are run
|-- artifacts/        <- NOT in the zip, gets auto-created when scripts are run
|-- results/          <- NOT in the zip, gets auto-created when scripts are run
```

I have not included `data/`, `artifacts/` and `results/` in this
repository/zip on purpose, since they get auto-created the moment the
scripts are run (the embeddings file alone is around 27 MB, no point
shipping that).

## Design decisions I want to explain

**Why cosine similarity and not plain Euclidean distance?**
Every vector is normalised to length 1 (L2 normalisation) before it is
stored. Once vectors are normalised, cosine similarity between two of
them becomes exactly the same as their dot product, which is just one
fast matrix multiplication in numpy. That's why the search code in this
project looks so simple - most of the "cosine similarity math" is already
handled by the normalising step.

**Why TF-IDF + SVD for text embeddings, and not something like word2vec
or a proper sentence transformer model?**
TF-IDF + SVD (this combination is usually called LSA) is a real, standard,
well known text embedding technique, and it does not need to download any
big pretrained model from the internet. This means the project runs
anywhere without depending on internet access or large model downloads.
It's not the most powerful embedding technique out there, but it produces
real vectors with real topic-based clusters in them, which is exactly
what was needed to make clustering (IVF-Flat) meaningful. The assignment
itself pointed out that real embeddings are "lumpy" and more interesting
to test against than pure random vectors, which is why I did not just
generate random numpy vectors directly.

**Why IVF-Flat and not HNSW?**
The assignment described IVF-Flat as the "gentler path" and HNSW as
"harder and more impressive", but said either is fine. Since this is for
a selection task, I decided it's better to submit something that is fully
correct, fully tested and fully explained, rather than something more
impressive-looking but half-working. So I picked IVF-Flat and made sure
every part of it (including my own k-means, not sklearn's) is implemented
and benchmarked properly.

**About delete in the approximate index, and why the assignment mentions
delete is "genuinely awkward" in these kinds of indexes:**
In IVF-Flat, every vector belongs to exactly one cluster. I store each
cluster as a Python dictionary of `{id: vector}` instead of one packed
numpy matrix per cluster. This was on purpose: with a dictionary,
deleting a vector is simple and cheap (just remove that one key). If
instead I had stored each cluster as a single numpy array (which is a
little faster to search), deleting even one vector would mean rebuilding
that entire cluster's array from scratch, every single time, which gets
slow as clusters grow. So I accepted a small extra cost at search time
(stacking the dictionary's vectors into a temporary array just for that
search) to keep delete simple and fast. This exact explanation is also
written as a comment inside `vectordb/ivf_flat.py`, right above the
`delete()` function.

**Why not use FAISS / Pinecone / Chroma / sklearn.neighbors?**
Because the assignment specifically said not to. Every part of the
similarity search, clustering, insert, search and delete logic inside the
`vectordb/` folder is written by me using plain numpy. The only external
library used anywhere in this project is scikit-learn's `TfidfVectorizer`
and `TruncatedSVD`, and that is used only in `scripts/generate_data.py`,
purely to turn text sentences into vectors in the first place - it has
nothing to do with the actual vector database logic, which only starts
after the vectors already exist.

## Things I would improve with more time

- IVF-Flat currently uses fixed values for number of clusters (256) and
  clusters searched per query (8). With more time I would add a script
  that tries a few different values of these and plots recall vs speed,
  to make it easier to pick the best setting for a given use case.
- I would like to also implement HNSW as a second approximate index
  option, since the assignment mentioned it as the more advanced path,
  but I did not have enough time to implement and test it as thoroughly
  as I wanted to for this submission.
- Right now, if you close the terminal without using `--save`, insert and
  delete changes made through the demo script are lost. A more
  production ready version would auto-save changes, or use proper
  file-based storage instead of a single pickle file for the whole
  database.

---

Thank you for checking my submission.
