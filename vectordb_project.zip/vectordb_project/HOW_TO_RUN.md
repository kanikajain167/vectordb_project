# How to Run This Project

This file is just for running the project, step by step, in exact order.
For the project explanation (what I built and why), please check
`README.md`.

Do these steps one by one, in this exact order. Do not skip a step,
because each step needs the files created by the step before it.

---

## Step 0: Install the requirements (do this only once)

Open a terminal inside the `vectordb_project` folder (the folder this
file is in), and run:

```
pip install -r requirements.txt
```

This installs numpy, scikit-learn and pytest.

Note: scikit-learn is used ONLY for converting text sentences into number
vectors (TF-IDF + SVD), in Step 1 below. The actual vector database part
- brute force search, k-means, IVF-Flat, insert/search/delete - is all
written by me using plain numpy, no vector database library and no
sklearn.neighbors is used anywhere, as the task required.

---

## Step 1: Generate the data

```
python scripts/generate_data.py
```

This will take about 10-15 seconds.

What it does:
- Creates 55,000+ short text sentences across 40 topics.
- Converts every sentence into a 128-number vector.
- Sets aside 500 sentences as test queries, and works out their correct
  (exact) top-10 nearest neighbours in advance, to use as the answer key
  later.
- Saves everything into a new `data/` folder (this folder gets created
  automatically, you don't need to make it yourself).

You should see output ending something like this:

```
Done. Files written to .../data
  corpus.json                  ~5800 KB
  embeddings.npy              ~27000 KB
  query_texts.json               ~32 KB
  query_embeddings.npy          ~250 KB
  ground_truth.npy               ~39 KB
  embedder.pkl                 ~3900 KB
```

---

## Step 2: Build the indexes

```
python scripts/build_and_save.py
```

This will take about 5-10 seconds.

What it does:
- Loads the vectors created in Step 1.
- Trains the IVF-Flat index (runs k-means to make 256 clusters).
- Loads all the vectors into both the exact index and the approximate
  index.
- Saves the whole built database as `artifacts/vector_db.pkl`, so it
  does not need to be rebuilt again and again every time.

You should see output ending something like this:

```
Exact index size: 54500
Approx index size: 54500

Saved built index to .../artifacts/vector_db.pkl (~56 MB)
```

---

## Step 3: Run the benchmark

```
python scripts/benchmark.py
```

This is the main result of the whole project - comparing the exact index
against the approximate index.

What it does:
- Loads the database saved in Step 2.
- Runs all 500 test queries through the exact index and notes the time.
- Runs the same 500 queries through the approximate index and notes the
  time.
- Compares the approximate index's answers to the correct answer key from
  Step 1 and works out "Recall@10" (out of the 10 correct answers, how
  many did the approximate index actually find).
- Prints a full report and also saves it to
  `results/benchmark_report.txt`.

Numbers I got on my machine (yours may be a little different, that is
normal):

```
Vectors indexed        : 54500
Exact  (brute force)    : mean ~1.3 ms per query
Approx (IVF-Flat)       : mean ~0.65 ms per query
Speedup                 : around 2x faster
Recall@10 mean          : around 0.985 (98.5%)
```

---

## Step 4: Try it yourself (the demo)

There are a few ways to run the demo depending on what you want to show.

**Important thing to understand before this step:** 4a below opens an
interactive `query>` prompt that ONLY accepts plain sentences to search
for, nothing else. Options 4b, 4c and 4d are DIFFERENT, separate commands
that you type directly at your normal terminal prompt (the one that
looks like `PS C:\...>` or `$`), not inside the `query>` prompt. If you
type something like `--insert "..."` into the `query>` prompt it will
just search for that odd text as a sentence instead of actually inserting
anything, since the `query>` prompt does not understand command options.
So if you are inside the `query>` prompt and want to run 4b/4c/4d, first
type `exit` to leave it, and then run the command normally.

### 4a. Interactive mode (type any sentence)

```
python scripts/demo_query.py
```

This opens a prompt. Type any sentence and press enter, it will show the
top 10 closest matches from both the exact index and the approximate
index, side by side, with timing. Type `exit` to quit.

### 4b. One single query without going interactive

```
python scripts/demo_query.py --query "the striker scored a goal in the final match"
```

### 4c. Live demo of insert + search + delete (best one for a demo video)

```
python scripts/demo_query.py --live-demo
```

This single command, in one go:
1. Inserts a brand new sentence that was never in the original data.
2. Searches for it and shows it comes back as the #1 result with a
   perfect match score of 1.0.
3. Deletes that same sentence from both indexes.
4. Searches again and proves it is now gone from the results.

I would suggest using this command specifically for the demo video, since
it proves insert, search AND delete all working, in a single run.

### 4d. Insert or delete and keep it saved permanently

By default, insert/delete through the demo script only affects that one
run (this is on purpose, so running the demo again and again does not
keep changing the saved data file by accident). If you want a change to
actually stick, add `--save`:

```
python scripts/demo_query.py --insert "The robot vacuum cleaned the living room." --save
python scripts/demo_query.py --delete 1234 --save
```

---

## Step 5 (optional but I would recommend running this): automated tests

Type `exit` first if you are still inside the `query>` prompt from Step 4,
then run this at your normal terminal prompt:

```
pytest tests/ -v
```

This runs 15 tests I wrote to check that insert, search and delete are
actually working correctly (not just tested by running the scripts and
looking at the screen). All 15 were passing when I submitted this.

---

## Quick summary (all commands together)

```
pip install -r requirements.txt
python scripts/generate_data.py
python scripts/build_and_save.py
python scripts/benchmark.py
python scripts/demo_query.py --live-demo
pytest tests/ -v
```

That's it, that is the complete project, start to finish.
